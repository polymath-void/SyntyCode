from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="syntycode",
    version="1.0.0",
    author="Zero-Syntax Foundation",
    description="A universal Zero-Syntax Relational Graph Engine for AI and polyglot architectures.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/syntycode/SyntyCode",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    entry_points={
        'console_scripts': [
            'syntycode=syntycode.cli:main',
        ],
    },
)
