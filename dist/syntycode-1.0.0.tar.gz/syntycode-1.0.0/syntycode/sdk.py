import sqlite3
import uuid
import json
from typing import List, Dict, Any, Optional

import os

def get_architect_root():
    return os.getcwd()

DB_PATH = os.path.join(get_architect_root(), "agy_nodeos.db")

class Node:
    """Base Semantic Node in the Zero-Syntax Graph."""
    def __init__(self, node_type: str, name: str, properties: Dict[str, Any] = None):
        self.id = uuid.uuid4().hex
        self.node_type = node_type
        self.name = name
        self.properties = properties or {}
        self.children: List['Node'] = []
        self.calls: List['Node'] = []
        self.references: List['Node'] = []

    def add_child(self, node: 'Node'):
        self.children.append(node)
        return node

    def add_call(self, target_node: 'Node'):
        self.calls.append(target_node)
        
    def add_reference(self, var_node: 'Node'):
        self.references.append(var_node)

class Identifier(Node):
    def __init__(self, name: str):
        super().__init__("Identifier", name)

class Variable(Node):
    def __init__(self, name: str, value_or_call: Node = None, value_type: str = None, raw_value: Any = None):
        super().__init__("Variable", name, {"value_type": value_type, "raw_value": raw_value})
        if value_or_call:
            self.add_child(value_or_call)

class Call(Node):
    def __init__(self, target_name: str, args: List[str] = None):
        super().__init__("Call", target_name, {"args": args or []})

class Condition(Node):
    def __init__(self, check: Node, on_true: Node, on_false: Node = None):
        super().__init__("Condition", "if_statement")
        self.add_child(check)
        self.add_child(on_true)
        if on_false:
            self.add_child(on_false)

class Function(Node):
    def __init__(self, name: str, inputs: List[str] = None):
        super().__init__("Function", name, {"inputs": inputs or []})

    def add_statement(self, node: Node):
        self.add_child(node)
        return node

class Import(Node):
    def __init__(self, module_name: str, names: List[str] = None):
        super().__init__("Import", module_name, {"names": names or []})

class ClassNode(Node):
    def __init__(self, name: str, inherits: str = None):
        super().__init__("ClassNode", name, {"inherits": inherits})

    def add_method(self, func: Node):
        self.add_child(func)
        return func

class Block(Node):
    def __init__(self, name: str = "block"):
        super().__init__("Block", name)
        
    def add_statement(self, node: Node):
        self.add_child(node)
        return node

class Loop(Node):
    def __init__(self, loop_type: str, condition: str):
        super().__init__("Loop", loop_type, {"condition": condition})
        self.block = Block("loop_body")
        self.add_child(self.block)
        
    def add_statement(self, node: Node):
        self.block.add_statement(node)
        return node

class TryCatch(Node):
    def __init__(self, exception_type: 'str | List[str]' = "Exception", exception_var: 'str | None' = "e"):
        super().__init__("TryCatch", "try_catch", {"exception_type": exception_type, "exception_var": exception_var})
        self.try_block = Block("try")
        self.catch_block = Block("catch")
        self.add_child(self.try_block)
        self.add_child(self.catch_block)

class Return(Node):
    def __init__(self, value: Node = None):
        super().__init__('Return', 'return')
        if value:
            self.add_child(value)

class BinaryOp(Node):
    def __init__(self, operator: str, left: Node, right: Node):
        super().__init__('BinaryOp', operator, {'operator': operator})
        self.add_child(left)
        self.add_child(right)

class UnaryOp(Node):
    def __init__(self, operator: str, operand: Node):
        super().__init__('UnaryOp', operator, {'operator': operator})
        self.add_child(operand)

class Comparison(Node):
    def __init__(self, operator: str, left: Node, right: Node):
        super().__init__('Comparison', operator, {'operator': operator})
        self.add_child(left)
        self.add_child(right)

class Enum(Node):
    def __init__(self, name: str, members: List[str] = None):
        super().__init__('Enum', name, {'members': members or []})

class Interface(Node):
    def __init__(self, name: str):
        super().__init__('Interface', name)
    def add_method(self, func: Node):
        self.add_child(func)
        return func

class Decorator(Node):
    def __init__(self, name: str, args: List[str] = None):
        super().__init__('Decorator', name, {'args': args or []})

class GraphContext:
    """Context Manager for building and committing a semantic graph."""
    def __init__(self, module_name: str):
        self.module = Node("Module", module_name)
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if not exc_type:
            self.commit_to_db()
            
    def add_node(self, node: Node):
        self.module.add_child(node)
        return node
            
    def add_function(self, func: Function):
        self.module.add_child(func)
        return func
        
    def _traverse_and_insert(self, cursor, node: Node, parent_id: Optional[str] = None):
        cursor.execute(
            "INSERT OR REPLACE INTO nodes (node_id, node_type, name, filepath, hash) VALUES (?, ?, ?, ?, ?)",
            (node.id, node.node_type, node.name, "sdk_generated", json.dumps(node.properties))
        )
        if parent_id:
            cursor.execute(
                "INSERT OR IGNORE INTO edges (source_id, target_id, relation_type) VALUES (?, ?, ?)",
                (parent_id, node.id, "CONTAINS")
            )
        for call_target in node.calls:
            cursor.execute(
                "INSERT OR IGNORE INTO edges (source_id, target_id, relation_type) VALUES (?, ?, ?)",
                (node.id, call_target.id, "CALL")
            )
        for child in node.children:
            self._traverse_and_insert(cursor, child, node.id)

    def commit_to_db(self):
        import normalizer
        normalizer.normalize_graph(self.module)
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS nodes (node_id TEXT PRIMARY KEY, node_type TEXT, name TEXT, filepath TEXT, hash TEXT)")
        cursor.execute("CREATE TABLE IF NOT EXISTS edges (source_id TEXT, target_id TEXT, relation_type TEXT, PRIMARY KEY (source_id, target_id, relation_type))")
        self._traverse_and_insert(cursor, self.module)
        conn.commit()
        conn.close()
        print(f"[NodeOS SDK] Successfully committed Module '{self.module.name}' to {DB_PATH}")
