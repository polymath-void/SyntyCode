# SyntyCode: Zero-Syntax Relational Graph Engine

SyntyCode is a universal, language-agnostic software architecture engine. Instead of storing software logic in brittle, string-based text files (`.py`, `.ts`, `.rs`), SyntyCode stores logic as a highly optimized, mathematically pure **Relational Graph** inside a SQLite database. 

A central Universal Decoder then instantly transpiles that database graph natively into Python, TypeScript, Rust, Go, Java, and 19 other languages.

## 🚀 The Real World Use Cases

1. **Flawless AI-Driven Software Engineering**
   LLMs hallucinate syntax (missing brackets, indentation errors). By generating structured SQL data instead of raw text, the AI focuses purely on *logic*. The SyntyCode decoder mathematically guarantees 100% perfect syntax in the target language.
2. **"Write Once, Compile Anywhere" (Universal SDKs)**
   Model your backend or SDK logic once in the database. Swap the decode target from `python` to `rust` or `typescript` to instantly generate an enterprise-grade microservice or API client in a completely different language.
3. **The Codebase as a Queryable Database (Instant Analytics)**
   Because your codebase is a relational database, complex architectural analysis is just a native SQL query. Instantly find dead code, or use a Recursive CTE to see exactly which files will break if you modify a specific class (Blast Radius).
4. **No-Code / Visual Programming Backend**
   SyntyCode’s database schema (`ast_nodes` and `ast_edges`) is the perfect backend for a drag-and-drop web UI (like Unreal Engine Blueprints).

## 📦 Dependencies

SyntyCode is engineered to be ruthlessly lightweight and universally executable.
- **Python 3.8+** (For the Decoder & CLI)
- **SQLite3** (For the Relational Graph DB)
- *Zero third-party `pip` or `npm` dependencies.*

## 💻 Manual Usage (Human Developers)

To build software natively in SyntyCode, you do not write Python or TypeScript. You execute raw SQL.

### 1. Initialize the Database
```bash
sqlite3 agy_nodeos.db < schema.sql
```

### 2. Ingest Logic via SQL
```sql
BEGIN TRANSACTION;
INSERT INTO modules (module_name) VALUES ('DirectApp');
CREATE TEMP TABLE _ctx (key TEXT PRIMARY KEY, val INTEGER);

-- Define a Module and a File
INSERT INTO ast_nodes (module_id, node_type, name, scope_path) VALUES (1, 'Module', 'DirectApp', 'DirectApp');
INSERT INTO _ctx VALUES ('module', last_insert_rowid());
INSERT INTO ast_nodes (module_id, node_type, name, scope_path) VALUES (1, 'FileNode', 'main', 'DirectApp.main');
INSERT INTO _ctx VALUES ('file1', last_insert_rowid());

-- Define a Class
INSERT INTO ast_nodes (module_id, node_type, name, scope_path) VALUES (1, 'ClassNode', 'UserAuth', 'DirectApp.main.UserAuth');
INSERT INTO _ctx VALUES ('class', last_insert_rowid());

-- Wire the Edges
INSERT INTO ast_edges (source_id, target_id, relation_type, sequence_index) VALUES 
((SELECT val FROM _ctx WHERE key='module'), (SELECT val FROM _ctx WHERE key='file1'), 'CONTAINS', 0),
((SELECT val FROM _ctx WHERE key='file1'), (SELECT val FROM _ctx WHERE key='class'), 'CONTAINS', 0);
COMMIT;
```

### 3. Decode the Codebase
```bash
# Decode to Python (Creates main.py)
python cli.py decode DirectApp python --out-dir output_code

# Switch stack to Rust instantly (Creates main.rs)
python cli.py decode DirectApp rust --out-dir output_code
```

## 🤖 AI Agent Adaptation & Skill Injection

SyntyCode is uniquely optimized for autonomous AI Agents. AI agents should **never** attempt to write `.py` or `.ts` files manually when operating in a SyntyCode project. 

To train your AI agent to use SyntyCode natively:
1. Locate the `.agent_skill/SKILL.md` file bundled in this repository.
2. Copy this file into your AI's prompt context, or drop it into your local agent frameworks (e.g., `.agents/skills/syntycode/`).
3. This skill protocol provides the agent with the exact relational schema definitions, JSON node vocabularies, and SQL atomic staging patterns needed to become a native *Zero-Syntax Graph Engineer*.
