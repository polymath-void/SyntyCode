---
name: syntycode-engine
description: Standard Operating Procedure for Zero-Syntax Graph Engineering. Instructs agents on how to construct complex software architectures purely via raw SQLite insertions instead of text-based coding.
version: 1.0.0
---

# SyntyCode Engine: Agent Operating Procedure

**Core Philosophy:** You are a Zero-Syntax Graph Engineer. You do NOT write `.py`, `.ts`, or `.rs` files directly. You do NOT generate intermediate JSON files. You define logic natively by inserting relational AST nodes into the `agy_nodeos.db` SQLite database. The decoder engine guarantees 100% flawless cross-language transpilation.

## 1. Database Schema (The Source of Truth)
You must execute raw SQL against these three tables in `agy_nodeos.db`:
- **`modules`**: `(module_id, module_name)`
- **`ast_nodes`**: `(node_id, module_id, node_type, name, scope_path, properties)`
  *Note: `properties` must be a valid JSON dictionary string (e.g., `'{"inputs": ["self"]}'`).*
- **`ast_edges`**: `(source_id, target_id, relation_type, sequence_index)`
  *Note: `sequence_index` is critical for ordering statements in a block or parameters in a call.*

## 2. Agent SQL Ingestion Pattern
Because `node_id` is an `INTEGER PRIMARY KEY AUTOINCREMENT`, you must capture IDs on-the-fly using a temporary `_ctx` table within an atomic transaction.

```sql
BEGIN TRANSACTION;
-- 1. Initialize Context
INSERT INTO modules (module_name) VALUES ('MyProject');
CREATE TEMP TABLE _ctx (key TEXT PRIMARY KEY, val INTEGER);
INSERT INTO _ctx VALUES ('module', last_insert_rowid());

-- 2. Define Nodes
INSERT INTO ast_nodes (module_id, node_type, name, scope_path) VALUES ((SELECT val FROM _ctx WHERE key='module'), 'FileNode', 'main', 'MyProject.main');
INSERT INTO _ctx VALUES ('file_main', last_insert_rowid());

-- 3. Wire Edges
INSERT INTO ast_edges (source_id, target_id, relation_type, sequence_index) VALUES 
((SELECT val FROM _ctx WHERE key='module'), (SELECT val FROM _ctx WHERE key='file_main'), 'CONTAINS', 0);
COMMIT;
```

## 3. Node Vocabulary & Properties
Use the following `node_type` declarations carefully:
*   **Architecture Nodes:** `Module`, `FileNode`, `ClassNode`, `Function`
    *   *Function Properties:* `'{"inputs": ["arg1", "arg2"], "is_method": true}'`
*   **Logic Nodes:** `Condition`, `Loop`, `Block`, `Return`, `ThrowNode`
*   **Variable Nodes:** `Variable` (Left-hand side assignment)
*   **Expression Nodes:** `Call`, `BinaryOp`, `Identifier`
    *   *Call Properties:* `'{"args": ["arg1", "arg2"]}'`
    *   *BinaryOp Properties:* `'{"operator": "=="}'`
*   **Data Structures:** `DictNode`, `ArrayNode`
    *   *DictNode Properties:* `'{"keys": ["key1", "key2"]}'`
*   **Access Nodes:** `MemberAccess`, `IndexAccess`
    *   *IndexAccess Safety:* Pass `'{"safe": true}'` to gracefully handle missing dictionary keys in strict languages like Python (transpiles to `.get()`).

## 4. Multi-File Codebase Generation
If the target architecture requires multiple files:
1. Make `FileNode`s the direct children of the `Module`.
2. Attach `ClassNode`s or `Function`s as the direct children of specific `FileNode`s.
3. Decode the project using the `--out-dir` parameter.

## 5. Execution & Decoding
Once the SQL transaction is committed, invoke the SyntyCode CLI to transpile the database graph into physical codebase files:

```bash
python SyntyCode/cli.py decode <ModuleName> python --out-dir output_python
python SyntyCode/cli.py decode <ModuleName> typescript --out-dir output_typescript
```

## Critical Anti-Patterns
❌ **NEVER** write code strings manually. (e.g., do not write `def hello():` into the `name` column).
❌ **NEVER** forget `sequence_index`. Edges will execute in random order if they all share `0`.
❌ **NEVER** ignore scoping. Ensure `scope_path` accurately tracks hierarchy (e.g., `Module.File.Class.Function`).
